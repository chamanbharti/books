package com.rawsanj.mail;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class FileZip {

	public void zipFile(String filePath){
        
        FileOutputStream fos = null;
        ZipOutputStream zipOut = null;
        FileInputStream fis = null;
        try {
            fos = new FileOutputStream("D:/ImpactProductCustomer.zip");
            zipOut = new ZipOutputStream(new BufferedOutputStream(fos));
            File input = new File(filePath);
            fis = new FileInputStream(input);
            ZipEntry ze = new ZipEntry(input.getName());
            System.out.println("Zipping the file: "+input.getName());
            zipOut.putNextEntry(ze);
            byte[] tmp = new byte[4*1024];
            int size = 0;
            while((size = fis.read(tmp)) != -1){
                zipOut.write(tmp, 0, size);
            }
            zipOut.flush();
            zipOut.close();
        } catch (FileNotFoundException e) {
           
            e.printStackTrace();
        } catch (IOException e) {
           
            e.printStackTrace();
        } finally{
            try{
                if(fos != null) fos.close();
                if(fis != null) fis.close();
            } catch(Exception ex){
                 
            }
        }
    }
	
	 // create a file on demand (without save locally) and add to zip
    public ZipOutputStream zipFileWithoutSaveLocal(String zipFileName) throws IOException {

        String data = "Test data \n123\n456";
        String fileNameInZip = "abc.csv";
        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFileName));
        try {

            ZipEntry zipEntry = new ZipEntry(fileNameInZip);
            zos.putNextEntry(zipEntry);

            ByteArrayInputStream bais = new ByteArrayInputStream(data.getBytes());
            // one line, able to handle large size?
            //zos.write(bais.readAllBytes());

            // play safe
            byte[] buffer = new byte[1024];
            int len;
            while ((len = bais.read(buffer)) > 0) {
                zos.write(buffer, 0, len);
            }

            zos.closeEntry();
        }catch (Exception e) {
			e.printStackTrace();
		}
        return zos;
    }
    
    // create a file on demand (without save locally) and add to zip
    public static void zipFileWithoutSaveLocal2(String zipFileName) throws IOException {

        String data = "Test data \n123\n456";
        String fileNameInZip = "abc.csv";

        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFileName))) {

            ZipEntry zipEntry = new ZipEntry(fileNameInZip);
            zos.putNextEntry(zipEntry);

            ByteArrayInputStream bais = new ByteArrayInputStream(data.getBytes());
            // one line, able to handle large size?
            //zos.write(bais.readAllBytes());

            // play safe
            byte[] buffer = new byte[1024];
            int len;
            while ((len = bais.read(buffer)) > 0) {
                zos.write(buffer, 0, len);
            }

            zos.closeEntry();
            System.out.println("success");
        }

    }
     
    public static void main(String a[]) throws IOException{
         
//        FileZip mfe = new FileZip();
//        mfe.zipFile("C:\\Users\\Chaman Bharti\\Downloads\\mca marksheet.pdf");
    	 String filePath = "C:\\Users\\Chaman Bharti\\Downloads\\ImpactProductCustomer.csv";
    	zipFileWithoutSaveLocal2(filePath);
    	System.out.println("success");
    }
    
}
